package com.childmonitorai;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.provider.CallLog;
import android.util.Log;

import com.google.firebase.database.DatabaseReference;

import java.util.ArrayList;

public class CallMonitor {
    private FirebaseHelper firebaseHelper;
    private Context context;
    private ArrayList<CallData> callDataBatch = new ArrayList<>();

    public CallMonitor(FirebaseHelper firebaseHelper, Context context) {
        this.firebaseHelper = firebaseHelper;
        this.context = context;
    }

    public void monitorCalls() {
        ContentResolver contentResolver = context.getContentResolver();
        Cursor cursor = contentResolver.query(CallLog.Calls.CONTENT_URI, null, null, null, CallLog.Calls.DATE + " DESC LIMIT 10");

        if (cursor != null) {
            try {
                while (cursor.moveToNext()) {
                    int numberColumnIndex = cursor.getColumnIndex(CallLog.Calls.NUMBER);
                    int durationColumnIndex = cursor.getColumnIndex(CallLog.Calls.DURATION);
                    int typeColumnIndex = cursor.getColumnIndex(CallLog.Calls.TYPE);
                    int timestampColumnIndex = cursor.getColumnIndex(CallLog.Calls.DATE);

                    if (numberColumnIndex >= 0 && durationColumnIndex >= 0 && typeColumnIndex >= 0 && timestampColumnIndex >= 0) {
                        String number = cursor.getString(numberColumnIndex);
                        String duration = cursor.getString(durationColumnIndex);
                        String type = cursor.getString(typeColumnIndex);
                        String timestamp = cursor.getString(timestampColumnIndex);

                        // Add the data to the batch
                        callDataBatch.add(new CallData(number, duration, type, timestamp));

                        // Upload instantly if batch size exceeds limit
                        if (callDataBatch.size() >= 10) {
                            uploadBatchToFirebase();
                        }
                    }
                }
            } catch (Exception e) {
                Log.e("CallMonitor", "Error monitoring calls", e);
            } finally {
                cursor.close();
            }
        }
    }

    public void uploadBatchToFirebase() {
        DatabaseReference callsReference = firebaseHelper.getCallsReference();
        for (CallData callData : callDataBatch) {
            callsReference.push().setValue(callData);
        }
        callDataBatch.clear();  // Clear the batch after uploading
    }
}
