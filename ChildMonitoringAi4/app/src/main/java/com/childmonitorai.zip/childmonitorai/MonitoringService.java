package com.childmonitorai;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.provider.CallLog;
import android.provider.ContactsContract;
import android.provider.Telephony;
import android.util.Log;

public class MonitoringService extends Service {
    private static final String TAG = "MonitoringService";
    private FirebaseHelper firebaseHelper;
    private DataContentObserver contentObserver;
    private static final String PREFS_NAME = "com.childmonitorai.PREFS";
    private static final String KEY_USER_ID = "userId";
    private static final String KEY_DEVICE_ID = "deviceId";
    private static final String KEY_PHONE_MODEL = "phoneModel";
    private static final String KEY_IS_INITIALIZED = "isInitialized";

    private String userId = null;
    private String deviceId = null;
    private String phoneModel = null;
    private boolean isInitialized = false;

    @Override
    public void onCreate() {
        super.onCreate();
        // Load previously saved details
        loadSavedDetails();
    }

    private void loadSavedDetails() {
        SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        userId = prefs.getString(KEY_USER_ID, null);
        deviceId = prefs.getString(KEY_DEVICE_ID, null);
        phoneModel = prefs.getString(KEY_PHONE_MODEL, null);
        isInitialized = prefs.getBoolean(KEY_IS_INITIALIZED, false);
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            String action = intent.getAction();
            if ("UPDATE_DETAILS".equals(action)) {
                // Update service with new details
                updateServiceDetails(intent);
            }
        }

        // If not initialized, just keep the service running
        if (!isInitialized) {
            createForegroundNotification();
            return START_STICKY;
        }

        // If already initialized, set up content observers
        setupContentObservers();

        return START_STICKY;
    }

    private void updateServiceDetails(Intent intent) {
        // Extract new details from intent
        String newUserId = intent.getStringExtra("userId");
        String newDeviceId = intent.getStringExtra("deviceId");
        String newPhoneModel = intent.getStringExtra("phoneModel");

        // Validate and update details
        if (newUserId != null && newDeviceId != null && newPhoneModel != null) {
            userId = newUserId;
            deviceId = newDeviceId;
            phoneModel = newPhoneModel;

            // Save updated details
            SharedPreferences prefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = prefs.edit();
            editor.putString(KEY_USER_ID, userId);
            editor.putString(KEY_DEVICE_ID, deviceId);
            editor.putString(KEY_PHONE_MODEL, phoneModel);
            editor.putBoolean(KEY_IS_INITIALIZED, true);
            editor.apply();

            // Mark as initialized and set up content observers
            isInitialized = true;
            setupContentObservers();
        }
    }

    private void setupContentObservers() {
        // Initialize firebaseHelper with userId and phoneModel
        firebaseHelper = new FirebaseHelper(userId, phoneModel);

        // Initialize ContentObserver to monitor data changes
        contentObserver = new DataContentObserver(new Handler(), firebaseHelper, this);
        getContentResolver().registerContentObserver(CallLog.Calls.CONTENT_URI, true, contentObserver);
        getContentResolver().registerContentObserver(Telephony.Sms.CONTENT_URI, true, contentObserver);
        getContentResolver().registerContentObserver(ContactsContract.Contacts.CONTENT_URI, true, contentObserver);

        // Create foreground notification
        createForegroundNotification();
    }

    private void createForegroundNotification() {
        Notification notification;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    "MonitorServiceChannel",
                    "Monitoring Service",
                    NotificationManager.IMPORTANCE_LOW
            );
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) manager.createNotificationChannel(channel);

            notification = new Notification.Builder(this, "MonitorServiceChannel")
                    .setContentTitle("Child Monitoring Service")
                    .setContentText("Monitoring in background...")
                    .setSmallIcon(R.drawable.ic_launcher_foreground)
                    .build();
        } else {
            notification = new Notification.Builder(this)
                    .setContentTitle("Child Monitoring Service")
                    .setContentText("Monitoring in background...")
                    .setSmallIcon(R.drawable.ic_launcher_foreground)
                    .build();
        }

        startForeground(1, notification);
    }

    @Override
    public void onDestroy() {
        // Unregister ContentObserver
        if (contentObserver != null) {
            getContentResolver().unregisterContentObserver(contentObserver);
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}