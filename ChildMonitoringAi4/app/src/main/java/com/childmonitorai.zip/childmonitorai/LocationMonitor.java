package com.childmonitorai;

import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;

import com.google.firebase.database.DatabaseReference;

import java.util.ArrayList;

public class LocationMonitor implements LocationListener {
    private FirebaseHelper firebaseHelper;
    private Context context;
    private ArrayList<LocationData> locationDataBatch = new ArrayList<>();

    public LocationMonitor(FirebaseHelper firebaseHelper, Context context) {
        this.firebaseHelper = firebaseHelper;
        this.context = context;
    }

    public void monitorLocation() {
        LocationManager locationManager = (LocationManager) context.getSystemService(Context.LOCATION_SERVICE);
        if (locationManager != null) {
            try {
                locationManager.requestLocationUpdates(LocationManager.GPS_PROVIDER, 10000, 10, this);
            } catch (SecurityException e) {
                // Handle permission issues
            }
        }
    }

    @Override
    public void onLocationChanged(Location location) {
        LocationData locationData = new LocationData(location.getLatitude(), location.getLongitude(), System.currentTimeMillis());
        locationDataBatch.add(locationData);

        // Upload instantly if batch size exceeds limit
        if (locationDataBatch.size() >= 10) {
            uploadBatchToFirebase();
        }
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {}
    @Override
    public void onProviderEnabled(String provider) {}
    @Override
    public void onProviderDisabled(String provider) {}

    public void uploadBatchToFirebase() {
        DatabaseReference locationReference = firebaseHelper.getLocationReference();
        for (LocationData locationData : locationDataBatch) {
            locationReference.push().setValue(locationData);
        }
        locationDataBatch.clear();  // Clear the batch after uploading
    }
}
