package com.childmonitorai;

public class CallData {
    private String number;
    private String duration;
    private String type;
    private String timestamp;

    public CallData() {
        // Default constructor required for Firebase
    }

    public CallData(String number, String duration, String type, String timestamp) {
        this.number = number;
        this.duration = duration;
        this.type = type;
        this.timestamp = timestamp;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }
}
