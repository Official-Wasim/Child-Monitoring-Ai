package com.childmonitorai;

import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.util.Log;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class MainActivity extends AppCompatActivity {
    private static final String TAG = "MainActivity";
    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mAuth = FirebaseAuth.getInstance();
        mDatabase = FirebaseDatabase.getInstance().getReference();

        // Always check if service should be initialized
        initializeMonitoringService();
    }

    private void initializeMonitoringService() {
        // Start the service, but it won't fully initialize until login
        Intent serviceIntent = new Intent(this, MonitoringService.class);
        startService(serviceIntent);
    }

    @Override
    protected void onStart() {
        super.onStart();

        // Check if the user is logged in
        FirebaseUser currentUser = mAuth.getCurrentUser();
        if (currentUser == null) {
            // If not logged in, redirect to LoginActivity
            startActivity(new Intent(this, LoginActivity.class));
            finish();
            return;
        }

        // Check and request permissions
        if (!PermissionHelper.hasPermissions(this)) {
            PermissionHelper.requestPermissions(this);
            return;
        }

        // Fetch user details and update monitoring service
        updateMonitoringServiceDetails(currentUser);
    }

    private void updateMonitoringServiceDetails(FirebaseUser firebaseUser) {
        // Get unique device ID
        String deviceId = Settings.Secure.getString(getContentResolver(), Settings.Secure.ANDROID_ID);
        String userId = firebaseUser.getUid();
        String phoneModel = android.os.Build.MODEL;

        // Fetch additional user details from Realtime Database
        DatabaseReference userRef = mDatabase.child("users").child(userId);
        userRef.addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.exists()) {
                    Log.d(TAG, "User ID: " + userId);
                    Log.d(TAG, "Device ID: " + deviceId);
                    Log.d(TAG, "Phone Model: " + phoneModel);

                    // Update monitoring service with details
                    Intent serviceIntent = new Intent(MainActivity.this, MonitoringService.class);
                    serviceIntent.setAction("UPDATE_DETAILS");
                    serviceIntent.putExtra("userId", userId);
                    serviceIntent.putExtra("deviceId", deviceId);
                    serviceIntent.putExtra("phoneModel", phoneModel);
                    startService(serviceIntent);
                } else {
                    Log.e(TAG, "No user document found");
                    Toast.makeText(MainActivity.this, "User details not found", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Log.e(TAG, "Error fetching user details", error.toException());
                Toast.makeText(MainActivity.this, "Failed to fetch user details", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (PermissionHelper.hasPermissions(this)) {
            // Re-check user and update monitoring service if permissions are granted
            FirebaseUser currentUser = mAuth.getCurrentUser();
            if (currentUser != null) {
                updateMonitoringServiceDetails(currentUser);
            }
        } else {
            Toast.makeText(this, "Permissions are required for the app to function.", Toast.LENGTH_SHORT).show();
        }
    }
}