package com.childmonitorai;

import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

public class FirebaseHelper {
    private final DatabaseReference rootRef;

    public FirebaseHelper(String userId, String phoneModel) {
        // Ensure userId and phoneModel are not null
        if (userId == null || phoneModel == null) {
            throw new IllegalArgumentException("userId or phoneModel cannot be null");
        }

        this.rootRef = FirebaseDatabase.getInstance()
                .getReference("users")
                .child(userId)
                .child("phones")
                .child(phoneModel);
    }

    public DatabaseReference getCallsReference() {
        return rootRef.child("calls");
    }

    public DatabaseReference getSmsReference() {
        return rootRef.child("sms");
    }

    public DatabaseReference getLocationReference() {
        return rootRef.child("location");
    }

    public DatabaseReference getContactsReference() {
        return rootRef.child("contacts");
    }
}